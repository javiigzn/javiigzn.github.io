let currentIndex = 0;
const images = document.querySelectorAll('.carousel img');
const totalImages = images.length;

function cambiarImagen(direction) {
    images[currentIndex].classList.remove('active');

    currentIndex = (currentIndex + direction + totalImages) % totalImages;

    images[currentIndex].classList.add('active');
}

images[currentIndex].classList.add('active');
