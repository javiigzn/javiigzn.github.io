// Comprobar si el usuario ya ha aceptado las cookies
if (!localStorage.getItem('cookiesAccepted')) {
    // Mostrar el banner si no se ha aceptado
    document.getElementById('cookie-banner').style.display = 'block';
}

// Acción cuando el usuario haga clic en el botón "Aceptar"
document.getElementById('accept-cookies').addEventListener('click', function() {
    // Guardar la preferencia del usuario en localStorage
    localStorage.setItem('cookiesAccepted', 'true');
    
    // Ocultar el banner
    document.getElementById('cookie-banner').style.display = 'none';
});
