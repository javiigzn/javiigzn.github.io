// cookies.js

// Espera a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function() {
    const cookieMessage = document.getElementById('cookie-message');
    const acceptButton = document.getElementById('accept-cookies');
    
    // Si el botón de aceptar es presionado, oculta el mensaje de cookies
    acceptButton.addEventListener('click', function() {
        cookieMessage.style.display = 'none';
    });
});
